# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

# Create your views here.
def HomeNFL(request):
	return render(request,'home/HomeNFL.html')



def TeamCowboys(request):
	return render(request,'home/TeamCowboys.html')

def TeamNewYorkGiants(request):
	return render(request,'home/TeamNewYorkGiants.html')

def TeamPhiladelphiaEagles(request):
	return render(request,'home/TeamPhiladelphiaEagles.html')

def TeamWashingtonRedskins(request):
	return render(request,'home/TeamWashingtonRedskins.html')



def TeamBuffalo(request):
	return render(request,'home/TeamBuffalo.html')

def TeamMiami(request):
	return render(request,'home/TeamMiami.html')

def TeamPatriots(request):
	return render(request,'home/TeamPatriots.html')

def TeamJets(request):
	return render(request,'home/TeamJets.html')




def TeamArizona(request):
	return render(request,'home/TeamArizona.html')

def TeamSanFrancisco(request):
	return render(request,'home/TeamSanFrancisco.html')

def TeamSeattle(request):
	return render(request,'home/TeamSeattle.html')

def TeamAngeles(request):
	return render(request,'home/TeamAngeles.html')



def TeamDenver(request):
	return render(request,'home/TeamDenver.html')

def TeamKansas(request):
	return render(request,'home/TeamKansas.html')

def TeamChargers(request):
	return render(request,'home/TeamChargers.html')

def TeamOakland(request):
	return render(request,'home/TeamOakland.html')



def TeamChicago(request):
	return render(request,'home/TeamChicago.html')

def TeamDetroit(request):
	return render(request,'home/TeamDetroit.html')

def TeamGreen(request):
	return render(request,'home/TeamGreen.html')

def TeamMinnesota(request):
	return render(request,'home/TeamMinnesota.html')



def TeamBaltimore(request):
	return render(request,'home/TeamBaltimore.html')

def TeamCincinnari(request):
	return render(request,'home/TeamCincinnari.html')

def TeamCleveland(request):
	return render(request,'home/TeamCleveland.html')

def TeamPittsburgh(request):
	return render(request,'home/TeamPittsburgh.html')



def TeamAtlanta(request):
	return render(request,'home/TeamAtlanta.html')

def TeamCarolina(request):
	return render(request,'home/TeamCarolina.html')

def TeamOrleans(request):
	return render(request,'home/TeamOrleans.html')

def TeamTampa(request):
	return render(request,'home/TeamTampa.html')



def TeamHouston(request):
	return render(request,'home/TeamHouston.html')

def TeamJacksonville(request):
	return render(request,'home/TeamJacksonville.html')

def TeamIndianapolis(request):
	return render(request,'home/TeamIndianapolis.html')

def TeamTennessee(request):
	return render(request,'home/TeamTennessee.html')

def vista(request):
	return render(request,'home/vista.html')