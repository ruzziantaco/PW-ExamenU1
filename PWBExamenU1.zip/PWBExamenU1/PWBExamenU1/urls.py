"""PWBExamenU1 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from NFL import views

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^$', views.HomeNFL, name='HomeNFL'),
    url(r'^TeamCowboys/$', views.TeamCowboys, name='TeamCowboys'),
    url(r'^TeamNewYorkGiants/$', views.TeamNewYorkGiants, name='TeamNewYorkGiants'),
    url(r'^TeamPhiladelphiaEagles/$', views.TeamPhiladelphiaEagles, name='TeamPhiladelphiaEagles'),
    url(r'^TeamWashingtonRedskins/$', views.TeamWashingtonRedskins, name='TeamWashingtonRedskins'),

    url(r'^TeamBuffalo/$', views.TeamBuffalo, name='TeamBuffalo'),
    url(r'^TeamMiami/$', views.TeamMiami, name='TeamMiami'),
    url(r'^TeamPatriots/$', views.TeamPatriots, name='TeamPatriots'),
    url(r'^TeamJets/$', views.TeamJets, name='TeamJets'),

    url(r'^TeamArizona/$', views.TeamArizona, name='TeamArizona'),
    url(r'^TeamSanFrancisco/$', views.TeamSanFrancisco, name='TeamSanFrancisco'),
    url(r'^TeamSeattle/$', views.TeamSeattle, name='TeamSeattle'),
    url(r'^TeamAngeles/$', views.TeamAngeles, name='TeamAngeles'),


    url(r'^TeamDenver/$', views.TeamDenver, name='TeamDenver'),
    url(r'^TeamKansas/$', views.TeamKansas, name='TeamKansas'),
    url(r'^TeamChargers/$', views.TeamChargers, name='TeamChargers'),
    url(r'^TeamOakland/$', views.TeamOakland, name='TeamOakland'),

    url(r'^TeamChicago/$', views.TeamChicago, name='TeamChicago'),
    url(r'^TeamDetroit/$', views.TeamDetroit, name='TeamDetroit'),
    url(r'^TeamGreen/$', views.TeamGreen, name='TeamGreen'),
    url(r'^TeamMinnesota/$', views.TeamMinnesota, name='TeamMinnesota'),

    url(r'^TeamBaltimore/$', views.TeamBaltimore, name='TeamBaltimore'),
    url(r'^TeamCincinnari/$', views.TeamCincinnari, name='TeamCincinnari'),
    url(r'^TeamCleveland/$', views.TeamCleveland, name='TeamCleveland'),
    url(r'^TeamPittsburgh/$', views.TeamPittsburgh, name='TeamPittsburgh'),

    url(r'^TeamAtlanta/$', views.TeamAtlanta, name='TeamAtlanta'),
    url(r'^TeamCarolina/$', views.TeamCarolina, name='TeamCarolina'),
    url(r'^TeamOrleans/$', views.TeamOrleans, name='TeamOrleans'),
    url(r'^TeamTampa/$', views.TeamTampa, name='TeamTampa'),

    url(r'^TeamHouston/$', views.TeamHouston, name='TeamHouston'),
    url(r'^TeamJacksonville/$', views.TeamJacksonville, name='TeamJacksonville'),
    url(r'^TeamIndianapolis/$', views.TeamIndianapolis, name='TeamIndianapolis'),
    url(r'^TeamTennessee/$', views.TeamTennessee, name='TeamTennessee'),
    url(r'^vista/$', views.vista, name='vista'),
]